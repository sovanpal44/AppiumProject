package appiumactivity;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import junit.framework.Assert;

public class project1 {

	AppiumDriver<MobileElement> driver;

	@Test
	public void f() throws InterruptedException, IOException {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceId", "653890fa");

		caps.setCapability("deviceName", "pro Redmi");

		caps.setCapability("platformName", "android");
		caps.setCapability("appPackage", "com.google.android.apps.tasks");

		caps.setCapability("appActivity", ".ui.TaskListsActivity");

		caps.setCapability("noReset", true);
		caps.setCapability("adbExecTimeout", "20000");

		driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);

		// Instantiate Appium Driver

		String task1 = "Complete Activity with Google Tasks";
		String task2 = "Complete Activity with Google keep";
		String task3 = "Complete the second Activity Google Keep";

		String[] taskArray = { task1, task2, task3 };

		for (int i = 0; i < 3; i++) {

			System.out.println("Task name to be added: " + taskArray[i]);
			addTask(taskArray[i]);
		}

		verifyTask(taskArray);

	}

	public void addTask(String taskName) {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementById("tasks_fab").click();
		driver.findElementById("add_task_title").sendKeys(taskName);
		driver.findElement(MobileBy.AndroidUIAutomator("text(\"Save\")")).click();

	}

	public void verifyTask(String[] tasksName) {

		List<MobileElement> addedTaskName = driver.findElementsByXPath("//android.widget.TextView[contains(@resource-id, 'task_name')]");
		Assert.assertEquals(addedTaskName.get(0).getText(), tasksName[2]);
		Assert.assertEquals(addedTaskName.get(1).getText(), tasksName[1]);
		Assert.assertEquals(addedTaskName.get(2).getText(), tasksName[0]);

	}

}
