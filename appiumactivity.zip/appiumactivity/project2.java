package appiumactivity;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class project2 {

	AppiumDriver<MobileElement> driver;

	@BeforeTest
	public void beforeTest() throws MalformedURLException {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceId", "653890fa");

		caps.setCapability("deviceName", "pro Redmi");

		caps.setCapability("platformName", "android");
		caps.setCapability("appPackage", "com.google.android.keep");

		caps.setCapability("appActivity", ".activities.BrowseActivity");

		caps.setCapability("noReset", true);
		caps.setCapability("adbExecTimeout", "20000");

		driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);

	}

	@Test
	public void googleKeep() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementById("new_note_button").click();
		driver.findElementById("edit_note_text").sendKeys("Test");
		driver.findElementById("editable_title").sendKeys("Testabcd");
	}

	@Test(dependsOnMethods = { "googleKeep" })
	public void back() {
		driver.findElementByXPath("//android.widget.ImageButton[@content-desc=\"Open navigation drawer\"]").click();

	}

	@Test(dependsOnMethods = { "back" })
	public void verify() {

		String Note = driver.findElementById("index_note_text_description").getText();
		String Title = driver.findElementById("index_note_title").getText();
		Assert.assertEquals("Test", Note);
		Assert.assertEquals("Testabcd", Title);

	}

	@Test(dependsOnMethods = { "verify" })
	public void delete() {

		driver.findElementByXPath("//android.widget.LinearLayout[contains(@resource-id, 'browse_note_interior_content')]").click();
		driver.findElementById("edit_note_text").clear();
		driver.findElementById("editable_title").clear();

	}

	@Test(dependsOnMethods = { "delete" })
	public void reminder() {

		googleKeep();
		driver.findElementByXPath("//android.widget.TextView[@content-desc=\"Single-column view\"]").click();
		List<MobileElement> addReminder = driver.findElementsByXPath("//android.widget.Spinner[contains(@resource-id, 'spinner_inside_error_state')]");
		addReminder.get(1).click();
		driver.findElementByXPath("//android.widget.TextView[contains(@text, 'Afternoon')]").click();
		driver.findElementById("save").click();

		verify();

		String Date = driver.findElementById("reminder_chip").getText();
		Assert.assertEquals("Tomorrow, 13:00", Date);

	}

	@AfterTest
	public void afterTest() {

	}

}
