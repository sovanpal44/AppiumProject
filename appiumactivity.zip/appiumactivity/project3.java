package appiumactivity;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class project3 {

	WebDriverWait wait;
	AppiumDriver<MobileElement> driver;

	@BeforeTest
	public void openBrowser() throws InterruptedException, IOException {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceId", "653890fa");

		caps.setCapability("deviceName", "pro Redmi");

		caps.setCapability("platformName", "android");
		caps.setCapability("appPackage", "com.android.chrome");

		caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");

		caps.setCapability("noReset", true);
		caps.setCapability("adbExecTimeout", "20000");

		driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
		wait = new WebDriverWait(driver, 10);

		driver.get("https://www.training-support.net/selenium");

	}

	@Test
	public void checkBrowser() {

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.view.View")));

		driver.findElement(MobileBy.AndroidUIAutomator("new UiScrollable(new UiSelector().className(\"android.view.View\")).scrollIntoView("
				+ "new UiSelector().description(\"To-Do List Elements get added at run time\"))")).click();

		String task1 = "Add tasks to list";
		String task2 = "Get number of tasks";
		String task3 = "Clear the list";

		String[] taskArray = { task1, task2, task3 };

		for (int i = 0; i < 3; i++) {

			System.out.println("Tasks to be added: " + taskArray[i]);
			addTask(taskArray[i]);

		}

		driver.findElement(By.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[2]/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View[2]"))
				.click();

		driver.findElement(By.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[2]/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View[3]"))
				.click();

		driver.findElement(By.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[1]/android.widget.FrameLayout[2]/android.webkit.WebView/android.view.View/android.view.View[3]/android.view.View[2]/android.view.View[4]"))
				.click();

		driver.findElementByXPath("//android.widget.TextView[contains(@text, 'Clear List')]").click();

		List<MobileElement> updatedList = driver.findElementsByXPath("//android.view.View[contains(@resource-id, 'tasksList')]");
		int updatedListsize = updatedList.size();

		Assert.assertEquals(1, updatedListsize);

	}

	private void addTask(String taskName) {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'taskInput')]").clear();
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'taskInput')]").sendKeys(taskName);

		driver.findElementByXPath("//android.widget.Button[contains(@text, 'Add Task')]").click();

	}

}
