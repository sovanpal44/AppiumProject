package appiumactivity;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class project4 {

	WebDriverWait wait;
	AppiumDriver<MobileElement> driver;

	@BeforeTest
	public void openBrowser() throws InterruptedException, IOException {

		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceId", "653890fa");

		caps.setCapability("deviceName", "pro Redmi");

		caps.setCapability("platformName", "android");
		caps.setCapability("appPackage", "com.android.chrome");

		caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");

		caps.setCapability("noReset", true);
		caps.setCapability("adbExecTimeout", "20000");

		driver = new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);
		wait = new WebDriverWait(driver, 10);

		driver.get("https://www.training-support.net/selenium");

	}

	@Test
	public void loginForm() {

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//android.view.View")));

		driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector().className(\"android.view.View\")).scrollIntoView(" + "new UiSelector().description(\"Login Form Please sign in.\"))"))
				.click();

	}

	@Test(priority = 0)
	public void validCredentials() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'username')]").sendKeys("admin");
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'password')]").sendKeys("password");
		driver.findElementByXPath("//android.widget.Button[contains(@text, 'Log in')]").click();
		String userMessage = driver.findElementByXPath("//android.view.View[contains(@resource-id, 'action-confirmation')]").getText();
		Assert.assertEquals("Welcome Back, admin", userMessage);

	}

	@Test(priority = 1)
	public void invalidCredentials() {

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'username')]").sendKeys("test");
		driver.findElementByXPath("//android.widget.EditText[contains(@resource-id, 'password')]").sendKeys("1234");
		driver.findElementByXPath("//android.widget.Button[contains(@text, 'Log in')]").click();
		String validationMessage = driver.findElementByXPath("//android.view.View[contains(@resource-id, 'action-confirmation')]").getText();
		Assert.assertEquals("Invalid Credentials", validationMessage);

	}

	@AfterTest
	public void afterTest() {
	}

}
